export default
    {
        burger: require('./image/burger.jpg'),
        kheer: require('./image/kheer.jpg'),
        machurian: require('./image/machurian.jpg'),
        noodles: require('./image/noodles.jpg'),
        paneertikka: require('./image/paneertikka.jpg'),
        pasta: require('./image/pasta.jpg'),
        pizza: require('./image/pizza.jpg'),
        springroll: require('./image/springroll.jpg'),
        actionbtn: require('./image/actionbtn.png'),
        usericon: require('./image/user_icon.png'),
        splash: require('./image/splash.jpg'),
    }