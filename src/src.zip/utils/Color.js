export const Colors = {
    APP_PRIMARY_COLOR: "#64E986",
    APP_BG_COLOR: "white",
    BORDER_COLOR: "#C9CAC9",
    PLACE_HOLDER_COLOR: "black",
    WHITE: "white",
    BLACK: "black",
    GREY: "#c6c6c6",
    BLUE:"#1761a0",
    Inputcolour:"#505050",
    MainColorOfApp:''
  
  };
  