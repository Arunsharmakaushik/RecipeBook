export default {
     
    recipe:"Recipe",
    book:'book',
    Volledig:"VOLLEDIG RECEPT"
 }